create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text not null default '',
  price_cents integer not null check (price_cents >= 0),
  image_url text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  discord_user_id text not null,
  discord_username text not null,
  product_id uuid references public.products(id),
  product_name text not null,
  amount_cents integer not null check (amount_cents >= 0),
  status text not null default 'pending'
    check (status in ('pending','approved','denied')),
  ticket_channel_id text,
  moderator_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists orders_status_created_idx
  on public.orders(status, created_at desc);
create index if not exists orders_user_idx
  on public.orders(discord_user_id);

-- Produtos de exemplo: edite ou substitua depois.
insert into public.products (name, description, price_cents, image_url)
select 'Produto de exemplo', 'Troque este texto pelo produto real.', 1500,
       'https://placehold.co/800x450/png'
where not exists (select 1 from public.products);
