# Bot de vendas para Discord

Projeto inicial em JavaScript com discord.js v14, Supabase e configuração Discloud.

## O que já está incluído
- `/comprar`: catálogo com descrição, preço, imagem e paginação.
- Botões de compra que criam um canal privado para cliente e moderadores.
- `/pedidos`: somente o cargo configurado em `MODERATOR_ROLE_ID`; botões para confirmar/negar.
- `/dashboard`: resumo por hoje, 7 dias, 30 dias ou todo o período.
- Persistência de produtos e pedidos no Supabase.

## 1. Preparar o Supabase
1. Conecte o Supabase ao ChatGPT quando solicitado para permitir operações MCP.
2. No painel Supabase, abra SQL Editor e execute `schema.sql`.
3. Copie a Project URL e a chave `service_role` para o `.env`. **Nunca compartilhe a service_role nem a envie ao Discord.**

## 2. Preparar o Discord
1. Crie uma aplicação e um bot no Discord Developer Portal.
2. Ative o bot e convide-o ao servidor com permissões para ver canais, enviar mensagens, incorporar links e gerenciar canais.
3. Copie o token, Application ID e Server ID.
4. Crie um cargo chamado Moderador e copie seu ID.
5. (Opcional) Crie uma categoria para tickets e copie seu ID.
6. Ative o Modo Desenvolvedor no Discord para copiar IDs.

## 3. Configurar localmente
1. Instale Node.js 24.17.0 ou superior (compatível com a versão atual do discord.js 14).
2. Renomeie `.env.example` para `.env` e preencha as variáveis.
3. No terminal, dentro da pasta:
   `npm install`
   `npm run commands`
   `npm start`

## 4. Hospedar na Discloud
Envie a pasta compactada com `index.js`, `package.json`, `discloud.config` e os demais arquivos. Configure as variáveis de ambiente no painel da hospedagem, se disponível. Não inclua o `.env` real no ZIP.

## Produtos
Cadastre/edite produtos na tabela `products` do Supabase. `price_cents` é o valor em centavos: R$ 19,90 = `1990`. `image_url` deve ser uma URL pública de imagem.

## Pagamentos
O projeto inicia com `PAYMENTS_TEST_MODE=true`: não gera nem valida cobranças. Para pagamentos reais, o responsável pela conta deve configurar o provedor de cobrança e validação por webhook. Não aprove pedidos apenas porque alguém enviou um comprovante ou clicou num botão; confirme o recebimento no provedor/banco.

## Segurança
- Use `service_role` apenas no servidor.
- Nunca publique o token do bot ou segredos do Supabase.
- O botão de aprovação é uma decisão administrativa; não é prova automática de pagamento.
- Restrinja a categoria dos tickets aos cargos necessários.
