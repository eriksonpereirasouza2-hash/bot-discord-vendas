import 'dotenv/config';
import { REST, Routes, SlashCommandBuilder } from 'discord.js';

const commands = [
  new SlashCommandBuilder()
    .setName('comprar')
    .setDescription('Abre o catálogo de produtos da loja.'),
  new SlashCommandBuilder()
    .setName('pedidos')
    .setDescription('Lista pedidos pendentes (somente moderadores).'),
  new SlashCommandBuilder()
    .setName('dashboard')
    .setDescription('Mostra o resumo de vendas (somente moderadores).')
    .addStringOption(option =>
      option.setName('periodo')
        .setDescription('Período do resumo')
        .setRequired(false)
        .addChoices(
          { name: 'Hoje', value: 'day' },
          { name: '7 dias', value: 'week' },
          { name: '30 dias', value: 'month' },
          { name: 'Tudo', value: 'all' }
        ))
].map(command => command.toJSON());

const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);
await rest.put(
  Routes.applicationGuildCommands(process.env.DISCORD_CLIENT_ID, process.env.DISCORD_GUILD_ID),
  { body: commands }
);
console.log('Comandos registrados no servidor.');
